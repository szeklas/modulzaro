function TeglaTestFelszin(a, b, c) {
    let felszin = 2 * (a * b + b * c + c * a)
    return felszin
}

document.write("Téglatest felszíne: " + TeglaTestFelszin(2, 3, 4))
document.write("<br>")
document.write("Téglatest felszíne: " + TeglaTestFelszin(1, 3, 5))
document.write("<br>")
document.write("Téglatest felszíne: " + TeglaTestFelszin(2, 4, 8))


document.write("<hr>")




function TeglaTestTerfogat(a, b, c) {
    let terfogat = a * b * c
    return terfogat
}


document.write("Téglatest térfogata: " + TeglaTestTerfogat(2, 3, 4))
document.write("<br>")
document.write("Téglatest térfogata: " + TeglaTestTerfogat(1, 3, 5))
document.write("<br>")
document.write("Téglatest térfogata: " + TeglaTestTerfogat(2, 4, 8))


document.write("<hr>")




function PhErtek(vizsgaltErtek) {
    if (vizsgaltErtek > 7) {
        return "Lúgos állapot"
    }
    else if (vizsgaltErtek < 7) {
        return "Savas állapot"
    }
    else if (vizsgaltErtek == 7) {
        return "Semleges állapot"
    }
}
document.write(PhErtek(9))
document.write("<br>")
document.write(PhErtek(5.5))
document.write("<br>")
document.write(PhErtek(7))


document.write("<hr>")




function ElsoNSzamOsszege(szamokMennyisege){
	let szamokOsszeadasa=0
    for(let i=0;i<=szamokMennyisege;i++){
    	szamokOsszeadasa+=i
    }
    return szamokOsszeadasa
}
document.write(ElsoNSzamOsszege(3))
document.write("<br>")
document.write(ElsoNSzamOsszege(10))
document.write("<br>")
document.write(ElsoNSzamOsszege(21))

document.write("<hr>")




function RnSzam(also, felso) {
    let generaltSzam = Math.round(Math.random() * (felso - also) + also)
    return generaltSzam
}




function TombGenerator(meret, also, felso) {
    let tomb = []
    for (let i = 0; i < meret; i++) {
        let generaltSzamok = RnSzam(also, felso)
        tomb.push(generaltSzamok)
    }
    return tomb
}

let szamok = TombGenerator(5, 10, 100)
document.write(szamok)

document.write("<br>")




function PrimekSzama(vizsgaltTomb) {
    let oszto = 0
    let szamlalo = 0
    for (let i = 1; i <= vizsgaltTomb.length; i++) {
        if (vizsgaltTomb[i] % i == 0) {
            oszto++
        }
    }
    if (oszto == 2) {
        szamlalo++
    }
    return szamlalo
}
document.write("A tömbben lévő prím számok: " + PrimekSzama(szamok))

document.write("<hr>")




function EkezetesBetukSzama(vizsgaltSzoveg, betu1, betu2, betu3, betu4, betu5, betu6, betu7) {
    let karakterMennyiseg = 0
    for (let i = 0; i < vizsgaltSzoveg.length; i++) {
        if (vizsgaltSzoveg[i] == betu1 || vizsgaltSzoveg[i] == betu2 || vizsgaltSzoveg[i] == betu3 || vizsgaltSzoveg[i] == betu4 || vizsgaltSzoveg[i] == betu5 || vizsgaltSzoveg[i] == betu6 || vizsgaltSzoveg[i] == betu7) {
            karakterMennyiseg++
        }
    }
    return karakterMennyiseg
}

document.write("Ékezetes betűk száma: ")
document.write(EkezetesBetukSzama("Szeretem a programozást", "á", "é", "ó", "ü", "ű", "ö", "ő"))

document.write("<br>")
document.write("Ékezetes betűk száma: ")
document.write(EkezetesBetukSzama("Géza kék az ég", "á", "é", "ó", "ü", "ű", "ö", "ő"))

document.write("<br>")
document.write("Ékezetes betűk száma: ")
document.write(EkezetesBetukSzama("Répa, retek, mogyoró", "á", "é", "ó", "ü", "ű", "ö", "ő"))

document.write("<hr>")




function SzamVisszafele(megforditandoSzam) {
    let szamVisszafele = 0
    for (let i = megforditandoSzam - 1; i >= 0; i--) {
        szamVisszafele += megforditandoSzam[i]
    }
    return szamVisszafele
}
document.write(SzamVisszafele("2024"))
document.write("<br>")
document.write(SzamVisszafele("1222"))
document.write("<br>")
document.write(SzamVisszafele("8481"))